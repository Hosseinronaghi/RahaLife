Future<void> createNativeDatabaseSafetyCopy() async {}
